package com.example.wifi;

import android.bluetooth.BluetoothAdapter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class Bluetooth extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        Button b1 = (Button) findViewById(R.id.button);
        TextView t1 = (TextView) findViewById(R.id.text1);

        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        b1.setOnClickListener(view -> {

            if (mBluetoothAdapter.isEnabled()) {
                if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {

                    return;
                }
                mBluetoothAdapter.disable();
                t1.setText("Bluetooth is ON");
            } else {
                mBluetoothAdapter.enable();
                t1.setText("Bluetooth is OFF");
            }
        });
    }

}