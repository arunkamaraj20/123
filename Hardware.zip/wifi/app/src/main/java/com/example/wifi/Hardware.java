package com.example.wifi;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Hardware extends AppCompatActivity
{

    private Button Bt, wi, cam, sensorr;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware);


        Bt = findViewById(R.id.bluetooth);
        wi = findViewById(R.id.wifibutton);
        cam = findViewById(R.id.camera_button);
        sensorr = findViewById(R.id.sensorButton);

        Bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Hardware.this, "Bluetooth clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Hardware.this , Bluetooth.class));
            }
        });

        wi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Hardware.this, "Wifi clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Hardware.this , Wifi.class));
            }
        });

        cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Hardware.this, "Camera clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Hardware.this , Camera.class));
            }
        });

        sensorr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Hardware.this, "Sensor clicked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Hardware.this , Sensor.class));
            }
        });
    }

}