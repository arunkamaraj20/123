package com.example.sqlite_sp_firereal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "myPrefs";
    private static final String DARK_MODE_KEY = "darkMode"; // Key for dark mode setting
    private static final String USERNAME_KEY = "username";
    private static final String PASSWORD_KEY = "password";

    private EditText editTextUsername, editTextPassword;
    private Button buttonSave;
    private Switch switchDarkMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);

        // Find views
        switchDarkMode = findViewById(R.id.switch_dark_mode);
        editTextUsername = findViewById(R.id.edit_text_username);
        editTextPassword = findViewById(R.id.edit_text_password);
        buttonSave = findViewById(R.id.button_save);

        // Load the previous state of the dark mode setting (if available)
        switchDarkMode.setChecked(sharedPreferences.getBoolean(DARK_MODE_KEY, false));

        // Set username and password if previously saved
        editTextUsername.setText(sharedPreferences.getString(USERNAME_KEY, ""));
        editTextPassword.setText(sharedPreferences.getString(PASSWORD_KEY, ""));

        // Handle switch toggle events for dark mode
        switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(DARK_MODE_KEY, isChecked);
            editor.apply();
            applyDarkMode(isChecked);
            Toast.makeText(SettingsActivity.this, "Dark Mode " + (isChecked ? "Enabled" : "Disabled"), Toast.LENGTH_SHORT).show();
        });

        // Handle save button click
        buttonSave.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();
            // Save username and password
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(USERNAME_KEY, username);
            editor.putString(PASSWORD_KEY, password);
            editor.apply();
            Toast.makeText(SettingsActivity.this, "Data Saved", Toast.LENGTH_SHORT).show();
        });
    }

    private void applyDarkMode(boolean isDarkMode) {
        int mode = isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_NO;
        AppCompatDelegate.setDefaultNightMode(mode);
        recreate(); // Apply the new theme immediately
    }
}
